const DEFAULT_HOST = "localhost:7823";
const RECONNECT_MS = 5000;
const POLL_ALARM  = "ramwarden-poll";

const IS_FIREFOX = navigator.userAgent.includes("Firefox");

// ── Firefox alarm listener — registered at TOP LEVEL so it survives event-page restarts.
// When Firefox suspends the event page and wakes it for an alarm, this listener is
// re-registered before the alarm event fires. setInterval cannot survive suspension.
if (IS_FIREFOX && chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === POLL_ALARM) _poll();
  });
}

// The warden's questions: a "?" badge while one waits, answered in the popup.
// Once a minute is plenty; the daemon spaces its questions 45 minutes apart.
const WARDEN_ALARM = "ramwarden-warden";
async function _checkWarden() {
  try {
    const r = await fetch(_httpUrl + "/warden/bubble");
    const s = r.ok ? await r.json() : null;
    _asking = !!(s && s.pet !== false && s.bubble && (s.bubble.choices || []).length);
  } catch { _asking = false; }
  if (_connected) _badge(true);
}
if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === WARDEN_ALARM) _checkWarden(); });
  chrome.alarms.create(WARDEN_ALARM, { periodInMinutes: 1 });
}
chrome.runtime.onMessage?.addListener((msg) => { if (msg?.type === "warden-answered") _checkWarden(); });

let _host    = DEFAULT_HOST;
let _wsUrl   = `ws://${DEFAULT_HOST}/ws`;
let _httpUrl = `http://${DEFAULT_HOST}`;

// Stable per-browser ID persisted in local storage.
// NOT held in memory as a module-level var — event page restarts clear memory.
// _poll() always reads it fresh from storage to avoid the null race.
let ws = null;

// ── URL protection ────────────────────────────────────────────────────────────

const PROTECTED_PREFIXES = [
  "chrome://", "brave://", "about:", "chrome-extension://",
  "moz-extension://", "devtools://", "edge://", "opera://",
  "vivaldi://", "data:", "javascript:", "file://",
];

const PROTECTED_PATTERNS = [
  /^https?:\/\/localhost/i,
  /^https?:\/\/127\./,
  /^https?:\/\/192\.168\./,
  /^https?:\/\/10\.\d/,
  /accounts?\.(google|microsoft|apple|github)\./i,
  /console\.|dashboard\.|admin\./i,
];

// Sign-in flows are protected only when the path *starts* with one of these, the
// same rule the daemon applies (tabpolicy.rs). Matching anywhere in the path
// protected finished OAuth callbacks and any page with "/login" deep in its URL,
// so the daemon listed them as candidates and this guard refused every one: no
// tab was ever unloaded.
const AUTH_PATH_PREFIXES = ["/login", "/signin", "/auth", "/oauth", "/callback", "/session"];

function hasAuthPath(url) {
  try {
    const path = new URL(url).pathname.toLowerCase();
    return AUTH_PATH_PREFIXES.some(p => path.startsWith(p));
  } catch {
    return true; // an unparseable URL is not ours to touch
  }
}

function isProtected(url) {
  if (!url) return true;
  if (PROTECTED_PREFIXES.some(p => url.startsWith(p))) return true;
  if (PROTECTED_PATTERNS.some(r => r.test(url))) return true;
  if (hasAuthPath(url)) return true;
  return false;
}

// Protections that hold however long a tab sits: browser pages, private hosts
// (dev servers, the router) and editors whose state lives in the tab. Every other
// protection lifts once the tab has been left alone for RELEASE_MINUTES, the same
// rule as the daemon's tabpolicy::is_protected_for.
const RELEASE_MINUTES = 240;
const HARD_PATTERNS = [
  /^https?:\/\/localhost/i, /^https?:\/\/127\./, /^https?:\/\/192\.168\./, /^https?:\/\/10\.\d/,
  /^https?:\/\/172\.(1[6-9]|2\d|3[01])\./,
  /^https?:\/\/([^/]*\.)?(vscode\.dev|github\.dev|codesandbox\.io|stackblitz\.com|replit\.com|colab\.research\.google\.com)(\/|$|:)/i,
];

function isHardProtected(url) {
  if (!url || !/^https?:\/\//i.test(url)) return true;
  return HARD_PATTERNS.some(r => r.test(url));
}

// Mirrors tabpolicy::is_work_page: signed-in consoles, registrars, and pages in
// the middle of a form, order or setting. Never closed unattended. (2026-11-02:
// an Oracle Cloud DB console, an Agensi submit form and Namecheap were closed.)
const WORK_HOSTS = ["cloud.oracle.com","oraclecloud.com","portal.azure.com","cloud.mongodb.com",
  "cloud.digitalocean.com","app.netlify.com","vercel.com","supabase.com","railway.app","fly.io",
  "namecheap.com","godaddy.com","porkbun.com","name.com","dynadot.com","domains.squarespace.com",
  "domains.google.com","dash.cloudflare.com"];
const WORK_SEGMENTS = ["submit","new","create","edit","compose","upload","publish","apply","checkout",
  "cart","shoppingcart","basket","signup","register","onboarding","settings","account","billing",
  "admin","dashboard","console"];
const WORK_PREFIXES = ["submit","create","checkout","upload","publish","apply"];
function isWorkPage(url) {
  let u; try { u = new URL(url); } catch { return false; }
  if (!/^https?:$/.test(u.protocol)) return false;
  const host = u.hostname.toLowerCase();
  if (WORK_HOSTS.some(h => host === h || host.endsWith("." + h))) return true;
  return u.pathname.split("/").some(raw => {
    const seg = raw.toLowerCase();
    return WORK_SEGMENTS.includes(seg) || WORK_PREFIXES.some(p => seg.startsWith(p + "-") || seg.startsWith(p + "_"));
  });
}
// Mirrors tabpolicy::is_disposable_browser_page: settings pages hold no work.
const DISPOSABLE_PAGES = ["extensions","settings","history","downloads","newtab","new-tab-page","bookmarks","version","help","flags"];
function isDisposableBrowserPage(url) {
  const m = /^(chrome|edge|brave|vivaldi|opera):\/\/([^/?#]+)/i.exec(url || "");
  return !!m && DISPOSABLE_PAGES.includes(m[2].toLowerCase());
}
// The site a tab is on, for reopen matching: reopening Namecheap from the
// address bar lands on a different URL than the page that was closed.
function siteOf(url) {
  try { const h = new URL(url).hostname.toLowerCase(); return h ? h.split(".").slice(-2).join(".") : ""; }
  catch { return ""; }
}

function isProtectedFor(url, idleMinutes) {
  if (isHardProtected(url)) return true;
  return isProtected(url) && idleMinutes < RELEASE_MINUTES;
}

function _idleMinutes(tab) {
  const last = Math.max(tabActivity[tab.id]?.lastActiveMs || 0, tab.lastAccessed || 0);
  return last ? (Date.now() - last) / 60000 : 0;
}

// ── Tab activity tracking ─────────────────────────────────────────────────────

let tabActivity = {};
const selectedByWindow = new Map();
let lastActivitySample=Date.now();
function accountForActivityGap(now) {
  const gap=now-lastActivitySample;
  // A missing heartbeat is unknown time (sleep, browser/worker suspension).
  // Do not convert that gap into abandonment evidence.
  if (gap>60000) for (const row of Object.values(tabActivity)) {
    if (Number.isFinite(row.lastActiveMs)) row.lastActiveMs=Math.min(now,row.lastActiveMs+gap);
  }
  lastActivitySample=now;
}
function mergeActivity(stored) {
  for (const [id, row] of Object.entries(stored || {})) {
    const live=tabActivity[id];
    if (!live || (row.lastActiveMs || 0) > (live.lastActiveMs || 0)) tabActivity[id]=row;
  }
}


chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
  // Reading counts until the user leaves, not merely when they first selected it.
  const previous=selectedByWindow.get(windowId);
  if (previous && tabActivity[previous]) tabActivity[previous].lastActiveMs=Date.now();
  selectedByWindow.set(windowId,tabId);
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) return;
    _leaveIdleGroup(tab);

    // Keep the last 24 activations: the daemon turns them into a frecency score
    // (how often, and how recently, this tab is actually visited).
    const prior = tabActivity[tabId]?.activations ?? [];
    tabActivity[tabId] = {
      url: tab.url || "",
      title: tab.title || tab.url || "",
      lastActiveMs: Date.now(),
      incognito: tab.incognito || false,
      activations: [...prior, Date.now()].slice(-24),
    };
    persistActivity();
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    // Navigating within a site (Namecheap's control panel, a console) is the same
    // piece of work: keep its visit history. A new site starts fresh.
    const prior = tabActivity[tabId];
    const keep = prior && siteOf(prior.url) && siteOf(prior.url) === siteOf(changeInfo.url);
    tabActivity[tabId] = {url:changeInfo.url,lastActiveMs:Date.now(),activations:keep ? (prior.activations || []) : []};
    delete safety.work[tabId]; persistSafety(); persistActivity();
  }
  if (changeInfo.status !== "complete") return;
  tabActivity[tabId] = {
    url: tab.url || "",
    title: tab.title || tab.url || "",
    lastActiveMs: tabActivity[tabId]?.lastActiveMs ?? (tab.lastAccessed || Date.now()),
    incognito: tab.incognito || false,
    activations: tabActivity[tabId]?.activations ?? [],
  };
  persistActivity();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  const url = tabActivity[tabId]?.url;
  if (url && !safetyClosing.has(tabId)) {
    delete safety.closed[url];
    postFeedback(url, "browser_removed");
  }
  safetyClosing.delete(tabId); delete safety.work[tabId]; persistSafety();
  delete tabActivity[tabId];
  persistActivity();
});

function persistActivity() {
  chrome.storage.local.set({ tabActivity, lastActivitySample });
}

chrome.storage.local.get(["tabActivity","lastActivitySample"], (r) => {
  mergeActivity(r.tabActivity);
  if (Number.isFinite(r.lastActivitySample) && r.lastActivitySample>0) lastActivitySample=Math.min(lastActivitySample,r.lastActivitySample);
});

// Seed on load using real lastAccessed timestamps from the browser.
// Waits for the storage write to confirm before polling so _poll() sees the data.
chrome.tabs.query({}, (allTabs) => {
  const now = Date.now();
  const FALLBACK_INACTIVE_MS = 30 * 60 * 1000;
  let seeded = 0;
  for (const tab of allTabs) {

    if (!tabActivity[tab.id]) {
      tabActivity[tab.id] = {
        url: tab.url || "",
        title: tab.title || tab.url || "",
        lastActiveMs: tab.lastAccessed || (now - FALLBACK_INACTIVE_MS),
        incognito: tab.incognito || false,
      };
      seeded++;
    }
  }
  console.log(`[RamWarden] seeded ${seeded} tabs (${allTabs.length} total, ${Object.keys(tabActivity).length} tracked)`);
  // Wait for storage write to complete, then poll — avoids race where _poll() reads
  // before persistActivity()'s async write has committed.
  chrome.storage.local.set({ tabActivity }, () => {
    if (IS_FIREFOX) _poll();
  });
});

// ── Shared helpers ────────────────────────────────────────────────────────────

// The live tab list is the source of truth; tabActivity only supplies "when was
// this last touched". Building the report from the stored map alone let entries
// from previous browser sessions survive forever — onRemoved never fired for them,
// so the daemon kept being handed IDs of tabs that no longer existed, and every
// close aimed at ghosts.
async function buildTabReport(activity) {
  await safetyReady;
  return new Promise((resolve) => {
    chrome.tabs.query({}, (liveTabs) => {
      if (chrome.runtime.lastError) {
        console.warn("[RamWarden] tabs.query failed:", chrome.runtime.lastError.message);
        resolve([]);
        return;
      }

      const now = Date.now();
      const liveIds = new Set(liveTabs.map(t => t.id));

      let pruned = 0;
      for (const id of Object.keys(activity)) {
        if (!liveIds.has(parseInt(id))) {
          delete activity[id];
          pruned++;
        }
      }
      if (pruned) {
        console.log(`[RamWarden] pruned ${pruned} stale tab entr${pruned === 1 ? "y" : "ies"}`);
        chrome.storage.local.set({ tabActivity: activity });
        for (const id of Object.keys(tabActivity)) if (!liveIds.has(Number(id))) delete tabActivity[id];
      }

      mergeActivity(activity);
      accountForActivityGap(now);
      const report = [];
      for (const tab of liveTabs) {
        const known = tabActivity[tab.id];
        if (tab.active) selectedByWindow.set(tab.windowId,tab.id);
        const lastActiveMs = tab.active ? now : Math.max(known?.lastActiveMs ?? 0, tab.lastAccessed ?? 0) || now;
        tabActivity[tab.id]={...known,url:tab.url || "",title:tab.title || "",lastActiveMs};
        observeReopen(tab);
        const page = safety.pages[tab.url] || {}, site = safety.sites[siteOf(tab.url)] || {};
        const feedback = {until: Math.max(page.until || 0, site.until || 0), negative: Math.max(page.negative || 0, site.negative || 0)};
        report.push({
          id: tab.id,
          url: tab.url || "",
          title: tab.title || tab.url || "",
          lastActiveMs,
          inactiveMinutes: Math.round((now - lastActiveMs) / 60000),
          incognito: tab.incognito || false,
          active: tab.active,
          pinned: tab.pinned,
          audible: tab.audible ?? false,
          discarded: tab.discarded ?? false,
          // Firefox has no per-tab opt-out and leaves this undefined; reporting
          // that as false marked every Firefox tab "browser opted out".
          autoDiscardable: tab.autoDiscardable !== false,
          status: tab.status,
          discardSupported: typeof chrome.tabs.discard === "function",
          safeCloseSupported: !IS_FIREFOX, // correlated close acknowledgements use the live socket
          activations: known?.activations ?? [],
          activityVersion: 1,
          workInProgress: safety.work[tab.id]?.url === tab.url && safety.work[tab.id]?.dirty === true,
          protectedUntilMs: feedback.until || 0,
          negativeFeedback: feedback.negative || 0,
        });
      }
      persistActivity();
      _unloaded = report.filter(t => t.discarded).length;
      _tidyIdleGroups(liveTabs);
      _badge(_connected);
      resolve(report);
    });
  });
}

// Closes are checked against the live tab, not tabActivity: that map can miss
// tabs after a service-worker restart, and a silently filtered batch never
// answered, so the daemon waited out its timeout and nothing closed. Every close
// command now gets a reply, even an empty one. Each closed tab is saved to
// releasedTabs, which the popup lists for one-click reopening.
const RELEASED_LIMIT = 200;

async function closeTabs(tabIds) {
  const tabs = [];
  for (const id of (tabIds || [])) {
    const tab = await new Promise(r => chrome.tabs.get(id, t => r(chrome.runtime.lastError ? null : t)));
    if (tab && !isProtectedFor(tab.url, _idleMinutes(tab)) && !tab.active && !tab.pinned && !tab.audible && !tab.incognito) tabs.push(tab);
  }
  const closed = [];
  for (const tab of tabs) {
    const ok = await new Promise(r => chrome.tabs.remove(tab.id, () => r(!chrome.runtime.lastError)));
    if (ok) closed.push(tab);
  }
  if (closed.length) await _rememberReleased(closed);
  _confirmClosed(closed.map(t => t.id));
  return closed.map(t => t.id);
}

async function _rememberReleased(tabs) {
  const r = await new Promise(res => chrome.storage.local.get("releasedTabs", res));
  const now = Date.now();
  const added = tabs.map(t => ({ url: t.url, title: t.title || t.url, closedAt: now }));
  const releasedTabs = [...added, ...(r?.releasedTabs || [])].slice(0, RELEASED_LIMIT);
  await new Promise(res => chrome.storage.local.set({ releasedTabs }, res));
}

function _confirmClosed(ids) {
  for (const id of ids) delete tabActivity[id];
  persistActivity();
  if (IS_FIREFOX) {
    if (ids.length) _poll();
  } else {
    _send({ action: "tabs_closed", tabIds: ids });
  }
}

// ── Idle group ─────────────────────────────────────────────────────────────────

// Unloaded tabs are gathered into one collapsed "Idle" group per window, so the
// tab strip shows the tabs in use and one chip for the rest. Nothing is closed:
// expanding the group shows them all, and a tab opened from it leaves the group.
// The group is found again by its title, so a service-worker restart needs no
// stored state. The user's own groups and pinned tabs are never touched.
const IDLE_PREFIX = "Idle";
const NO_GROUP = -1;
const wardenDiscarded = new Set();

function _idleTitle(n) { return `${IDLE_PREFIX} · ${n}`; }

async function _idleGroupIn(windowId) {
  const groups = await new Promise(r => chrome.tabGroups.query({ windowId }, g => r(chrome.runtime.lastError ? [] : g)));
  return groups.find(g => (g.title || "").startsWith(IDLE_PREFIX + " ·"));
}

async function _tidyIdleGroups(liveTabs) {
  if (!chrome.tabGroups?.query || typeof chrome.tabs.group !== "function") return;
  const byWindow = new Map();
  for (const t of liveTabs) {
    if (!byWindow.has(t.windowId)) byWindow.set(t.windowId, []);
    byWindow.get(t.windowId).push(t);
  }
  for (const [windowId, tabs] of byWindow) {
    const group = await _idleGroupIn(windowId);
    const gid = group?.id ?? NO_GROUP;
    const loose = tabs.filter(t => wardenDiscarded.has(t.id) && t.discarded && !t.pinned && !t.active && t.groupId === NO_GROUP);
    const members = tabs.filter(t => gid !== NO_GROUP && t.groupId === gid).length;
    // One tab is not worth a group of its own.
    if (!loose.length || (gid === NO_GROUP && loose.length < 2)) {
      if (group && group.title !== _idleTitle(members)) chrome.tabGroups.update(gid, { title: _idleTitle(members) });
      continue;
    }
    const ids = loose.map(t => t.id);
    const opts = gid === NO_GROUP ? { tabIds: ids, createProperties: { windowId } } : { tabIds: ids, groupId: gid };
    const newId = await new Promise(r => chrome.tabs.group(opts, id => r(chrome.runtime.lastError ? NO_GROUP : id)));
    if (newId === NO_GROUP) continue;
    chrome.tabGroups.update(newId, { title: _idleTitle(members + ids.length), color: "grey", collapsed: group ? group.collapsed : false });
  }
}

// A tab opened from the Idle group goes back to the strip.
async function _leaveIdleGroup(tab) {
  if (!chrome.tabGroups?.get || tab.groupId === undefined || tab.groupId === NO_GROUP) return;
  const group = await new Promise(r => chrome.tabGroups.get(tab.groupId, g => r(chrome.runtime.lastError ? null : g)));
  if (group && (group.title || "").startsWith(IDLE_PREFIX + " ·")) chrome.tabs.ungroup(tab.id, () => void chrome.runtime.lastError);
}

// The badge shows how many tabs RamWarden has unloaded: Chrome keeps them in
// the tab strip looking the same, so without it nothing seems to happen.
let _connected = false;
let _unloaded = 0;
// The warden has a question waiting (a "coming back to this tab?" check-in).
let _asking = false;

function _badge(connected) {
  _connected = connected;
  chrome.action.setBadgeText({ text: !connected ? "!" : _asking ? "?" : _unloaded ? String(_unloaded) : "" });
  chrome.action.setBadgeBackgroundColor({ color: !connected ? "#ef4444" : _asking ? "#c0392b" : "#22c55e" });
  chrome.action.setTitle?.({ title: connected
    ? `RamWarden: ${_unloaded} tab(s) unloaded (they stay in the tab strip and reload when clicked)`
    : "RamWarden: daemon offline" });
}

// ── Load config, then start the right transport ───────────────────────────────

chrome.storage.sync.get("daemonHost", (r) => {
  if (r.daemonHost) {
    _host    = r.daemonHost;
    _wsUrl   = `ws://${_host}/ws`;
    _httpUrl = `http://${_host}`;
  }
  if (IS_FIREFOX) {
    _startPolling();
  } else {
    _connect();
  }
});

// ── Firefox: HTTP polling ─────────────────────────────────────────────────────

async function _poll() {
  // Load browserId + tabActivity together from storage.
  // Always reads from storage (not in-memory) so alarm-triggered wakeups work
  // even though in-memory state is cleared on event page restart.
  const localData = await new Promise(r => chrome.storage.local.get(["browserId", "tabActivity"], r));
  let browserId = localData.browserId;
  if (!browserId) {
    browserId = "rw-" + Math.random().toString(36).slice(2, 10);
    chrome.storage.local.set({ browserId });
  }

  // Re-read host config if this is a fresh event page wake
  if (_httpUrl === `http://${DEFAULT_HOST}`) {
    const syncData = await new Promise(r => chrome.storage.sync.get("daemonHost", r));
    if (syncData.daemonHost) _httpUrl = `http://${syncData.daemonHost}`;
  }

  const activity = localData.tabActivity || {};
  const tabs = await buildTabReport(activity);
  console.log(`[RamWarden] poll → ${tabs.length} tabs to report (activity keys: ${Object.keys(activity).length})`);

  try {
    const resp = await fetch(_httpUrl + "/api/tabs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ browser_id: browserId, tabs }),
    });
    if (!resp.ok) {
      console.warn("[RamWarden] poll failed: HTTP", resp.status);
      _badge(false);
      return;
    }
    _badge(true);
    const data = await resp.json();
    for (const cmd of (data.commands || [])) {
      if (cmd.action === "close") await closeTabs(cmd.tabIds);
      if (cmd.action === "discard") await discardTabs(cmd);
      if (cmd.action === "keep_tabs") await keepTabs(cmd.tabs);
    }
  } catch (e) {
    console.warn("[RamWarden] poll fetch error:", e);
    _badge(false);
  }
}

function _startPolling() {
  if (chrome.alarms) {
    // periodInMinutes: Firefox minimum is 1 min; Chrome allows 0.5 in dev mode.
    // We use 0.5 — Firefox clamps to 1 min silently, Chrome uses it as-is.
    chrome.alarms.create(POLL_ALARM, { periodInMinutes: 0.5 });
  }
  // Initial poll is triggered by the tabs.query seeding callback above,
  // not here — that ensures tabActivity is populated before the first send.
}

// ── Chrome/Brave: WebSocket ───────────────────────────────────────────────────

function _connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) return;
  try {
    ws = new WebSocket(_wsUrl);
  } catch {
    setTimeout(_connect, RECONNECT_MS);
    return;
  }

  ws.onopen = () => {
    console.log("[RamWarden] WS connected to", _wsUrl);
    _badge(true);
    _sendTabReport();
  };

  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    switch (msg.action) {
      case "get_tabs": _sendTabReport(); break;
      case "close":    closeTabs(msg.tabIds); break;
      case "close_safe": closeSafe(msg); break;
      case "keep_tabs": keepTabs(msg.tabs); break;
      case "discard":  discardTabs(msg); break;
      case "ping":     _send({ action: "pong" }); break;
    }
  };

  ws.onclose = () => { _badge(false); setTimeout(_connect, RECONNECT_MS); };
  ws.onerror = () => { ws.close(); };
}

async function _sendTabReport() {
  const r = await new Promise(res => chrome.storage.local.get("tabActivity", res));
  const tabs = await buildTabReport(r.tabActivity || {});
  _send({ action: "tab_report", tabs });
}

function _send(obj) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

// Keep WS alive (Chrome/Brave only)
if (!IS_FIREFOX) {
  setInterval(() => {
    if (ws?.readyState === WebSocket.OPEN) { _send({ action: "ping" }); _sendTabReport(); }
    else _connect();
  }, 25000);
}


// Policy/ranking lives in Rust. This is the final race guard at the browser API.
async function discardTabs(command) {
  await safetyReady;
  const confirmed = [];
  const minimum = Math.max(5, Number(command.minInactiveMinutes) || 5);
  for (const target of (command.tabs || []).slice(0, 5)) {
    if(command.standaloneLite){
      const live=await new Promise(resolve=>chrome.storage.local.get(['liteEnabled','liteBudget'],resolve));
      if(live.liteEnabled!==true || _connected)break;
      const current=await new Promise(resolve=>chrome.tabs.query({},resolve));
      if(liteKeepSet(current,live.liteBudget).has(target.id))continue;
    }
    if (typeof chrome.tabs.discard !== "function") break;
    const tab = await new Promise(resolve => chrome.tabs.get(target.id, tab => {
      resolve(chrome.runtime.lastError ? null : tab);
    }));
    if (!tab || safety.work[tab.id]?.dirty || (safety.pages[tab.url]?.until||0)>Date.now() || tab.url !== target.url || isProtectedFor(tab.url, _idleMinutes(tab)) || tab.active || tab.pinned || tab.audible
        || tab.incognito || tab.discarded || tab.autoDiscardable === false || tab.status !== "complete") continue;
    const last = Math.max(tabActivity[tab.id]?.lastActiveMs || 0, tab.lastAccessed || 0);
    if (!last || (Date.now() - last) / 60000 < minimum) continue;
    // Check stored activity again: activation may have arrived while get awaited.
    if (Date.now() - (tabActivity[tab.id]?.lastActiveMs || last) < minimum * 60000) continue;
    const ok = await new Promise(resolve => chrome.tabs.discard(tab.id, result => {
      if (chrome.runtime.lastError) { resolve(false); return; }
      // Firefox may return no Tab from discard; confirm from fresh state.
      chrome.tabs.get(tab.id, observed => {
        resolve(!chrome.runtime.lastError && observed?.url === target.url && observed?.discarded === true);
      });
    }));
    if (ok) { confirmed.push(tab.id); wardenDiscarded.add(tab.id); }
  }
  if (!IS_FIREFOX) {
    _send({action: "tabs_discarded", requestId: command.requestId, tabIds: confirmed});
    await _sendTabReport();
  }
  // Poll transport reports the resulting discarded flags in its next report.
  return confirmed;
}

// Local feedback survives service-worker and browser restarts. No page text is collected.
let safety = {pages:{},closed:{},work:{},sites:{},closedSites:{}};
const safetyClosing = new Set();
const safetyReady = new Promise(resolve => chrome.storage.local.get("tabSafety", r => {
  safety = {pages:{},closed:{},work:{},sites:{},closedSites:{},...(r?.tabSafety || {})};
  const cutoff=Date.now()-30*86400000;
  for (const [url,p] of Object.entries(safety.pages)) if (p.updated<cutoff) delete safety.pages[url];
  for (const [url,p] of Object.entries(safety.closed)) if (p.at<cutoff) delete safety.closed[url];
  for (const [k,p] of Object.entries(safety.sites)) if (p.updated<cutoff) delete safety.sites[k];
  for (const [k,p] of Object.entries(safety.closedSites)) if (p.at<cutoff) delete safety.closedSites[k];
  resolve();
}));
function persistSafety() { chrome.storage.local.set({tabSafety:safety}); }
function postFeedback(url,kind) {
  if (typeof fetch === "function") fetch(_httpUrl+"/browser/feedback",{method:"POST",
    headers:{"Content-Type":"application/json"},body:JSON.stringify({url,kind})}).catch(()=>{});
}
function protectPage(url,kind) {
  const old=safety.pages[url] || {};
  safety.pages[url]={until:Date.now()+86400000,negative:Math.min(4,(old.negative||0)+1),updated:Date.now()};
  delete safety.closed[url];
  // A reopen protects the whole site, and each reopen counts: reopening a site
  // twice is the strongest "I am coming back to this" there is.
  const site=siteOf(url);
  if (kind==="reopened" && site) {
    const s=safety.sites[site] || {};
    safety.sites[site]={until:Date.now()+86400000,negative:Math.min(4,(s.negative||0)+1),updated:Date.now()};
    delete safety.closedSites[site];
  }
  persistSafety();
  if (kind==="reopened") postFeedback(url,kind);
}
function observeReopen(tab) {
  const url = tab.url || tab.pendingUrl || "";
  if (!url || safetyClosing.has(tab.id)) return;
  if (safety.closed[url] || safety.closedSites[siteOf(url)]) protectPage(url,"reopened");
}
async function keepTabs(targets) {
  await safetyReady;
  for (const t of targets || []) protectPage(t.url,"keep");
}
chrome.tabs.onCreated?.addListener(async tab => { await safetyReady; observeReopen(tab); });
chrome.runtime.onMessage?.addListener((message,sender) => {
  if (message?.type!=="rw_activity" || !sender.tab || sender.frameId!==0) return;
  const tab=sender.tab, now=Date.now();
  const old=tabActivity[tab.id] || {};
  tabActivity[tab.id]={...old,url:tab.url,title:tab.title,lastActiveMs:now,activations:old.activations||[]};
  if (message.dirty===true) safety.work[tab.id]={url:tab.url,dirty:true};
  persistActivity(); persistSafety();
});
async function closeSafe(command) {
  await safetyReady;
  const closed=[];
  for (const target of command.tabs || []) {
    if (Date.now()>=command.expiresAt || !Number.isFinite(command.expiresAt)) break;
    const tab=await new Promise(r=>chrome.tabs.get(target.id,t=>r(chrome.runtime.lastError?null:t)));
    const disposable=isDisposableBrowserPage(tab?.url);
    const approved=command.approved===true;
    if (!tab || tab.url!==target.url || (!approved && isWorkPage(tab.url))
      || (!approved && !disposable && (isProtected(tab.url) || isHardProtected(tab.url)))
      || tab.active!==false || tab.pinned!==false || tab.audible===true || tab.incognito
      || tab.status!=="complete" || tab.autoDiscardable===false
      || safety.work[tab.id]?.dirty || (!approved && (safety.pages[tab.url]?.until||0)>Date.now())
      || (!approved && _idleMinutes(tab)<Math.max(60,command.minInactiveMinutes||1440))) continue;
    safetyClosing.add(tab.id);
    const ok=await new Promise(r=>chrome.tabs.remove(tab.id,()=>r(!chrome.runtime.lastError)));
    if (ok) {
      safety.closed[tab.url]={at:Date.now()}; closed.push(tab);
      if (siteOf(tab.url)) safety.closedSites[siteOf(tab.url)]={at:Date.now()};
      postFeedback(tab.url,"confirmed");
    } else safetyClosing.delete(tab.id);
  }
  persistSafety();
  if (closed.length) await _rememberReleased(closed);
  _send({action:"tabs_closed_safe",requestId:command.requestId,tabIds:closed.map(t=>t.id)});
  return closed.map(t=>t.id);
}

// Standalone Lite: opt-in, reversible tab unloading only. Never closes tabs.
// Desktop policy takes over whenever its connection is healthy.
function liteKeepSet(tabs,value){
 const budget=Math.max(1,Math.min(50,Math.floor(Number(value)||6)));
 const recent=[...tabs].sort((a,b)=>Math.max(tabActivity[b.id]?.lastActiveMs||0,b.lastAccessed||0)-Math.max(tabActivity[a.id]?.lastActiveMs||0,a.lastAccessed||0));
 return new Set(recent.slice(0,budget).map(t=>t.id));
}
async function runStandaloneLite() {
  if (_connected) return [];
  await safetyReady;
  const settings=await new Promise(resolve=>chrome.storage.local.get(['liteEnabled','liteBudget'],resolve));
  if(settings.liteEnabled!==true)return [];
  const tabs=await new Promise(resolve=>chrome.tabs.query({},resolve));
  const keep=liteKeepSet(tabs,settings.liteBudget);
  const eligible=tabs.filter(t=>!keep.has(t.id)&&!isWorkPage(t.url)&&!isHardProtected(t.url)&&_idleMinutes(t)>=60);
  return discardTabs({tabs:eligible.slice(0,5).map(t=>({id:t.id,url:t.url})),minInactiveMinutes:60,requestId:'standalone-lite',standaloneLite:true});
}
if(chrome.alarms){
 const scheduleLite=enabled=>{if(enabled)chrome.alarms.create('ramwarden-standalone-lite',{periodInMinutes:1});else chrome.alarms.clear?.('ramwarden-standalone-lite');};
 chrome.storage.local.get('liteEnabled',settings=>scheduleLite(settings.liteEnabled===true));
 chrome.storage.onChanged?.addListener((changes,area)=>{if(area==='local' && changes.liteEnabled)scheduleLite(changes.liteEnabled.newValue===true);});
 chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='ramwarden-standalone-lite')runStandaloneLite();});
}
